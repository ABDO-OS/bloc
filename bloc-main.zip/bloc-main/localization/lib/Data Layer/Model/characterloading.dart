import 'package:flutter/material.dart';

class Characterloading extends StatefulWidget {
  const Characterloading({super.key});

  @override
  State<Characterloading> createState() => _CharacterloadingState();
}

class _CharacterloadingState extends State<Characterloading> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
