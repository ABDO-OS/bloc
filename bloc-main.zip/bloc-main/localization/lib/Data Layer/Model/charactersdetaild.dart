import 'package:flutter/material.dart';

class charactersDatailsScreen extends StatefulWidget {
  const charactersDatailsScreen({super.key});

  @override
  State<charactersDatailsScreen> createState() =>
      _charactersDatailsScreenState();
}

class _charactersDatailsScreenState extends State<charactersDatailsScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
