import 'package:flutter/material.dart';

class Characterlistwidget extends StatefulWidget {
  @override
  State<Characterlistwidget> createState() => _CharacterlistwidgetState();
}

class _CharacterlistwidgetState extends State<Characterlistwidget> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
