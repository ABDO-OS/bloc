String serverUrl = "https://thronesapi.com/";
String api = "api/";
String v2 = 'v2/';
