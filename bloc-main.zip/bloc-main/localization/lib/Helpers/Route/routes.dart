const String loginScreen = "/";
const String layoutScreen = "/layout_screen";
const String charactersDetails = "characters_datails_screen";
