package com.example.localization

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
