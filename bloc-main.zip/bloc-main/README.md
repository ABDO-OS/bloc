# bloc
applying statemangement using bloc (change theme, language and checking connective)
