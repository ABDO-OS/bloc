const String loginPage = '/';
const String layoutScreen = '/layout_screen';
const String characterDetails = 'character_details_screen';