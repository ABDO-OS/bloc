import 'package:shared_preferences/shared_preferences.dart';

SharedPreferences? sharedPreferences;
String theme = "l";
String selectedLang = "en";