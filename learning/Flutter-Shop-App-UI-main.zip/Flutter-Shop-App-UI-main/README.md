# Flutter Shop App UI build with ChatGPT

**Packages we are using:**

- flutter_svg: [link](https://pub.dev/packages/flutter_svg)

## [Watch it on YouTube](https://youtu.be/oLFQyUgVw_E)

Welcome to My AI-Driven App Building Series: Crafting a Flutter App with ChatGPT While Saving Time and Following Best Practices!

### Flutter Shop App - Final UI

![Preview](/gif.gif)

![App UI](/ui.png)
