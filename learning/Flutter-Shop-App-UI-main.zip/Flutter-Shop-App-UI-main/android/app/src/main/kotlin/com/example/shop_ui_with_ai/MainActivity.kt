package com.example.shop_ui_with_ai

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
